from django.urls import path
from . import views

urlpatterns = [
    path('search/', views.search),
    path('product/<int:id>/', views.product, name='product')
]