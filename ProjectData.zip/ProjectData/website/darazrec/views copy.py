from django.shortcuts import render
from django.http import HttpResponse
from .models import Products
# Create your views here.

from django.shortcuts import render, redirect
from .forms import TextInputForm

import re
import nltk
from nltk.tokenize import word_tokenize

valid_brands = ['Samsung', 'Apple', 'Huawei', 'Oppo', 'Nokia', 'TECNO Mobile', 'Xiaomi', 'Realme Mobile', 'Infinix', 'Vivo', 'Sony', 'HTC', 'LG', 'Lenovo', 'Motorola', 'Panasonic', 'Meizu', 'Acer', 'ZTE', 'Alcatel']

def say_helloX(request):
    products = Products.objects.all()
    print(products)
    a = 2
    b = 10
    c = a + b
    # return HttpResponse('Hello world')
    return render(request, 'hello.html')


def say_hello(request):
    if request.method == 'POST':
        form = TextInputForm(request.POST)
        if form.is_valid():
            text_input_value = form.cleaned_data['text']
            min_price, max_price, condition_type = extract_query_data(text_input_value)

            print(min_price, max_price, condition_type)

                
            form.save()
            return redirect('success')  # Create a success view or redirect to another page
    else:
        form = TextInputForm()

    return render(request, 'hello.html', {'form': form})


import re
from nltk import word_tokenize, pos_tag, ne_chunk

def extract_query_data(sentence):
    phone_brands = ['apple', 'samsung', 'huawei', 'google', 'oneplus', 'xiaomi', 'lg', 'sony', 'motorola', 'nokia', 'infinix', 'redmi', 'mi']

    phone_models = [
    # Apple
    'iphone 13 pro', 'iphone 13 mini', 'iphone se (2020)', 'iphone 12', 'iphone 11', 'iphone',
    # Samsung
    'galaxy s23', 'galaxy a13', 'galaxy a04', 'galaxy s22 ultra', 'galaxy z flip4', 'galaxy a73', 'galaxy a14', 'galaxy a23', 'galaxy a54', 'galaxy a32', 'galaxy s21 fe', 'galaxy z', 'galaxy a24', 'galaxy a34', 'galaxy m02s', 'galaxy m04', 's23', 'a13', 'a04', 's22 ultra', 'z flip4', 'a73', 'a14', 'a23', 'a54', 'a32', 's21 fe', 'z', 'a24', 'watch5', 'a34', 'm02s', 'm04',
    # Huawei
    'p40 pro', 'mate 40', 'nova 8', 'p30 lite', 'y9 prime',
    # Google
    'pixel 6 pro', 'pixel 5a', 'pixel 4a', 'pixel 3 xl', 'pixel 2',
    # Xiaomi
    'mi 11', 'note 10 pro', 'mi 10t pro', 'k40', 'poco x3','pocco',
    # Infinix
    'note 10 pro', 'hot 10', 'zero 8', 'smart 5', 's5']

    sentence = sentence.lower()

    brands = []
    for phone_brand in phone_brands:
        if phone_brand in sentence:
            brands.append(phone_brand)
            sentence = sentence.replace(phone_brand, '')

    models = []
    for phone_model in phone_models:
        if phone_model in sentence:
            models.append(phone_model)
            sentence = sentence.replace(phone_model, '')

    # Tokenize the sentence
    words = word_tokenize(sentence)

    
    # Part-of-speech tagging
    pos_tags = pos_tag(words)
    
    # Named entity recognition (NER)
    chunks = ne_chunk(pos_tags)
    
    # Extract numerical entities (including prices)
    # price_entities = [chunk for chunk in chunks if isinstance(chunk, tuple) and re.match(r'^\d+(k|\d+)?$', chunk[0])]
    price_entities = [chunk for chunk in chunks if isinstance(chunk, tuple) and re.match(r'^\d+(\.\d+)?(k|\d+)?$', chunk[0])]
    
    # Extract conditions (e.g., "less than", "greater than", "between")
    conditions = [chunk[0] for chunk in pos_tags if chunk[1] in ['JJR', 'RBR', 'IN']]
    
    # Process extracted entities and conditions to get min and max prices
    min_price, max_price = None, None

    values = []
    for i in range(len(price_entities)):
        if(r'k' in price_entities[i][0]):
            values.append(float(re.sub(r'k$', '', price_entities[i][0])) * 1000)
        else:
            values.append(float(price_entities[i][0]))

    values.sort()
    
    for cond in conditions:
        if (cond in ['less', 'under', 'below']):
            if (len(values) > 1):
                max_price = values[1]
            else:
                max_price = values[0]
        elif (cond in ['greater', 'above', 'over']):
            min_price = values[0]
        elif 'between' in conditions:
            min_price = values[0]
            max_price = values[1]
    
    return conditions, min_price, max_price




import re

def extract_specs(sentence):
    specs = {}

    # Extract RAM
    ram_match = re.search(r'(\d+)\s*gb\s*ram', sentence, re.IGNORECASE)
    if ram_match:
        specs['ram'] = ram_match.group(1)

    # Extract storage
    storage_match = re.search(r'(\d+)\s*GB\s*(?:storage|rom)', sentence, re.IGNORECASE)
    if storage_match:
        specs['storage'] = storage_match.group(1)

    # Extract camera
    camera_match = re.search(r'(\d+)\s*MP\s*camera', sentence, re.IGNORECASE)
    if camera_match:
        specs['camera'] = camera_match.group(1)

    # Check for conditions on RAM and camera
    if 'ram' in specs and 'storage' in specs:
        ram_condition_match = re.search(r'(\b(?:greater than|less than)\s*\d+\s*GB\b)', sentence, re.IGNORECASE)
        if ram_condition_match:
            specs['ram_condition'] = ram_condition_match.group(1)

    if 'camera' in specs:
        camera_condition_match = re.search(r'(\b(?:greater than|less than)\s*\d+\s*MP\b)', sentence, re.IGNORECASE)
        if camera_condition_match:
            specs['camera_condition'] = camera_condition_match.group(1)


    return specs






import re
from nltk.corpus import stopwords
def extract_ratings(sentence):
    nltk.download('stopwords')

    # Get the English stopwords list
    english_stopwords = set(stopwords.words('english'))

    # Tokenize the sentence
    words = word_tokenize(sentence)

    # Remove stopwords
    filtered_words = [word for word in words if word.lower() not in english_stopwords]

    # Join the filtered words to form a new sentence
    sentence = ' '.join(filtered_words)

    # Define regex patterns for different rating formats
    rating_patterns = [
        r'rating of (\d)',
        r'(\d)\s*star rating',
        r'rating\s*(\d)',
        r'(\d)\s*star'
    ]

    # Initialize ratings dictionary
    ratings = {}

    # Iterate through patterns and extract ratings
    for pattern in rating_patterns:
        match = re.search(pattern, sentence, re.IGNORECASE)
        if match:
            ratings['rating'] = match.group(1)
            break  # Break if a match is found

    return ratings

# # Example sentences
# sentences = [
#     "I give it a rating of 4.",
#     "This product has a 5 star rating.",
#     "Rating 3 for the service was excellent.",
#     "4 star review for the movie."
# ]

# # Extract ratings from each sentence
# for sentence in sentences:
#     extracted_ratings = extract_ratings(sentence)
#     print(f"Sentence: {sentence} => Extracted Ratings: {extracted_ratings}")









# Example sentence
sentence = "Samsung phone A33 with 64GB rom, and more than 12 MP camera"

# Extract specs
extracted_specs = extract_specs(sentence)

# Print the extracted specs
print("Extracted Specs:", extracted_specs)







# # Test the function with example sentences
# sentences = [
#     "samsung galaxy s21 iphone infinix galaxy a33 X XR 15 pro Find phones between 20000.2 and 25.5k",
#     "Less than 20k greater than 50000",
#     "under 30000 and over 250000",
#     "Over 5000",
#     "Under 50000",
#     "Greater than 50000",
#     "Less than 50k",
#     "Above 5000 and below 25000"
# ]

# for sentence in sentences:
#     conditions, min_price, max_price = extract_query_data(sentence)
#     print(f"Sentence: {sentence}")
#     print(f"Conditions: {conditions}, Min Price: {min_price}, Max Price: {max_price}")
#     print("-" * 40)

