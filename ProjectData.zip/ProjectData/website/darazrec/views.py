from django.shortcuts import render
from django.http import HttpResponse
from .models import Products
# Create your views here.

from django.shortcuts import render, redirect
from .forms import TextInputForm

from django.db import connection


import re
from nltk import word_tokenize, pos_tag, ne_chunk
from nltk.corpus import stopwords


def search(request):
    if request.method == 'POST':
        form = TextInputForm(request.POST)
        if form.is_valid():
            textInputValue = form.cleaned_data['text']
            newSentence, brands, models = extractBrandModel(textInputValue.lower())
            condition, minPrice, maxPrice = extractPricing(newSentence)
            specs = extractSpecs(newSentence)
            ratings = extractRatings(newSentence)

            print(brands, models, condition, minPrice, maxPrice, specs, ratings)

            query = "SELECT * FROM products"

            query1 = None
            if 'between' in condition:
                if (minPrice and maxPrice):
                    query1 = "price >= {0} AND price <= {1}".format(minPrice, maxPrice)
            elif 'under' in condition and 'over' in condition:
                if (minPrice and maxPrice):
                    query1 = "price <= {0} AND price >= {1}".format(minPrice, maxPrice)
            elif 'under' in condition and 'over' not in condition:
                if (maxPrice):
                    query1 = "price <= {0}".format(maxPrice)
            elif 'over' in condition and 'under' not in condition:
                if (minPrice):
                    query1 = "price >= {0}".format(minPrice)
            else:
                query1 = None


            query2 = None
            query3 = None
            query4 = None
            query5 = None
            if (specs):
                print(specs)
                try:
                    if (specs['ram']):
                        query2 = "ram >= {0}".format(specs['ram'])
                except: query2 = None
                
                try:
                    if (specs['storage']):
                        query3 = "rom >= {0}".format(specs['camera'])
                except: query3 = None

                try:
                    if (specs['camera']):
                        query4 = "camera >= {0}".format(specs['camera'])
                except: query4 = None

                try:
                    if (specs['pta']):
                        query5 = "title LIKE '%pta%'"
                except: query5 = None

            query6 = None
            if(ratings):
                try:
                    print(ratings['rating'])
                    if (ratings['rating']):
                        query6 = "rating >= {0}".format(ratings['rating'])
                except: query6 = None

            if (brands):
                query7 = "("
                for brand in brands:
                    query7 += "title LIKE '%{0}%' OR ".format(brand)
                query7 = query7[0:-4] + ')'
            else:
                query7 = None

            if (models):
                query8 = "("
                for model in models:
                    query8 += "title LIKE '%{0}%' OR ".format(model)
                query8 = query8[0:-4] + ')'
            else:
                query8 = None


            andCheck = False
            if(query1):
                if (andCheck):
                    query += ' AND ' + query1
                else:
                    query += ' WHERE ' + query1
                    andCheck = True
            if(query2):
                if (andCheck):
                    query += ' AND ' + query2
                else:
                    query += ' WHERE ' + query2
                    andCheck = True
            if(query3):
                if (andCheck):
                    query += ' AND ' + query3
                else:
                    query += ' WHERE ' + query3
                    andCheck = True
            if(query4):
                if (andCheck):
                    query += ' AND ' + query4
                else:
                    query += ' WHERE ' + query4
                    andCheck = True
            if(query5):
                if (andCheck):
                    query += ' AND ' + query5
                else:
                    query += ' WHERE ' + query5
                    andCheck = True
            if(query6):
                if (andCheck):
                    query += ' AND ' + query6
                else:
                    query += ' WHERE ' + query6
                    andCheck = True
            if(query7):
                if (andCheck):
                    query += ' AND ' + query7
                else:
                    query += ' WHERE ' + query7
                    andCheck = True
            if(query8):
                if (andCheck):
                    query += ' AND ' + query8
                else:
                    query += ' WHERE ' + query8
                    andCheck = True


            if (not query1 and not query2 and not query3 and not query4 and not query5 and not query6 and not query7 and not query8):
                values = newSentence.split(' ')
                like_conditions = ' OR '.join(["title LIKE '%" + value + "%'" for value in values])
                print(like_conditions)
                # Construct the SELECT query
                query = f"SELECT * FROM products WHERE {like_conditions}"

            try:
                pattern = r'\b(?:top|best)(?:\s*\d+)?\b'
                matches = re.findall(pattern, newSentence, flags=re.IGNORECASE)
                if(matches):
                    limit = matches[0].replace('top','').replace('best','').strip()
                    x = int(limit)
                    query += ' ORDER BY rating DESC LIMIT {0}'.format(x)
            except:
                query = query

            query += ';'


            print(query)

            # Execute the raw SQL query
            with connection.cursor() as cursor:
                cursor.execute(query)
                result = cursor.fetchall()
                print(len(result))

            return render(request, 'results.html', {'data': result})

            # form.save()
            # return redirect('success')  # Create a success view or redirect to another page
    else:
        form = TextInputForm()

    return render(request, 'search.html', {'form': form})


def product(request, id):
    query = "SELECT * FROM products WHERE id = {0}".format(id)
    with connection.cursor() as cursor:
        cursor.execute(query)
        product = cursor.fetchall()
        print(len(product))

    query = "SELECT * FROM reviews WHERE productid = {0}".format(id)
    with connection.cursor() as cursor:
        cursor.execute(query)
        reviews = cursor.fetchall()
        print(len(reviews))
    return render(request, 'product.html', {'product': product, 'reviews': reviews})

def extractBrandModel(sentence):
    phoneBrands = ['apple', 'samsung', 'huawei', 'google', 'oneplus', 'xiaomi', 'lg', 'sony', 'motorola', 'nokia', 'infinix', 'redmi', 'mi']
    phoneModels = [ # Apple
                    'iphone 13 pro', 'iphone 13 mini', 'iphone se (2020)', 'iphone 12', 'iphone 11', 'iphone',
                    # Samsung
                    'galaxy s23', 'galaxy a13', 'galaxy a04', 'galaxy s22 ultra', 'galaxy z flip4', 'galaxy a73', 'galaxy a14', 'galaxy a23', 'galaxy s21', 'galaxy a54', 'galaxy a32', 'galaxy s21 fe', 'galaxy z', 'galaxy a24', 'galaxy a34', 'galaxy m02s', 'galaxy m04', 'galaxy', 's23', 'a13', 'a04', 's22 ultra', 'z flip4', 'a73', 'a14', 'a23', 'a54', 'a32', 's21 fe', 'z', 'a24', 'watch5', 'a34', 'm02s', 'm04',
                    # Huawei
                    'p40 pro', 'mate 40', 'nova 8', 'p30 lite', 'y9 prime',
                    # Google
                    'pixel 6 pro', 'pixel 5a', 'pixel 4a', 'pixel 3 xl', 'pixel 2',
                    # Xiaomi
                    'mi 11', 'note 10 pro', 'mi 10t pro', 'k40', 'poco x3','pocco',
                    # Infinix
                    'note 10 pro', 'hot 10', 'zero 8', 'smart 5', 's5']
    
    brands = []
    for phoneBrand in phoneBrands:
        if phoneBrand in sentence:
            brands.append(phoneBrand)
            sentence = sentence.replace(phoneBrand, '')

    models = []
    for phoneModel in phoneModels:
        if phoneModel in sentence:
            models.append(phoneModel)
            sentence = sentence.replace(phoneModel, '')
    
    return sentence, brands, models


def extractPricing(sentence):
    words = word_tokenize(sentence)
    posTags = pos_tag(words)
    chunks = ne_chunk(posTags)
    
    priceEntities = [chunk for chunk in chunks if isinstance(chunk, tuple) and re.match(r'^\d+(\.\d+)?(k|\d+)?$', chunk[0])]
    
    conditions = [chunk[0] for chunk in posTags if chunk[1] in ['JJR', 'RBR', 'IN']]
    
    minPrice, maxPrice = None, None

    values = []
    for i in range(len(priceEntities)):
        if(r'k' in priceEntities[i][0]):
            value = float(re.sub(r'k$', '', priceEntities[i][0])) * 1000
            if (value > 1000):
                values.append(value)
        else:
            value = float(priceEntities[i][0])
            if (value > 1000):
                values.append(value)
    values.sort()
    
    if (len(values) > 0):
        for cond in conditions:
            if (cond in ['less', 'under', 'below']):
                if (len(values) > 1):
                    maxPrice = values[1]
                else:
                    maxPrice = values[0]
            elif (cond in ['greater', 'above', 'over']):
                minPrice = values[0]
            elif 'between' in conditions:
                minPrice = values[0]
                maxPrice = values[1]
    
    return conditions, minPrice, maxPrice




def extractSpecs(sentence):
    specs = {}

    ramMatch = re.search(r'(\d+)\s*gb\s*ram', sentence, re.IGNORECASE)
    if ramMatch:
        specs['ram'] = ramMatch.group(1)

    storageMatch = re.search(r'(\d+)\s*GB\s*(?:storage|rom)', sentence, re.IGNORECASE)
    if storageMatch:
        specs['storage'] = storageMatch.group(1)

    cameraMatch = re.search(r'(\d+)\s*MP\s*camera', sentence, re.IGNORECASE)
    if cameraMatch:
        specs['camera'] = cameraMatch.group(1)

    if ('pta' in sentence):
        specs['pta'] = 'pta'

    # Check for conditions on RAM and camera
    # if 'ram' in specs:
    #     ramConditionMatch = re.search(r'(\b(?:greater than|less than)\s*\d+\s*GB\b)', sentence, re.IGNORECASE)
    #     if ramConditionMatch:
    #         specs['ramCondition'] = ramConditionMatch.group(1)

    # if 'storage' in specs:
    #     storageConditionMatch = re.search(r'(\b(?:greater than|less than)\s*\d+\s*GB\b)', sentence, re.IGNORECASE)
    #     if storageConditionMatch:
    #         specs['storageCondition'] = storageConditionMatch.group(1)


    # if 'camera' in specs:
    #     cameraConditionMatch = re.search(r'(\b(?:greater than|less than)\s*\d+\s*MP\b)', sentence, re.IGNORECASE)
    #     if cameraConditionMatch:
    #         specs['cameraCondition'] = cameraConditionMatch.group(1)

    return specs


def extractRatings(sentence):

    englishStopwords = set(stopwords.words('english'))

    words = word_tokenize(sentence)

    filteredWords = [word for word in words if word.lower() not in englishStopwords]

    newSentence = ' '.join(filteredWords)

    ratingPatterns = [
        r'rating of (\d)',
        r'(\d)\s*star rating',
        r'rating\s*(\d)',
        r'(\d)\s*star'
    ]

    ratings = {}

    for pattern in ratingPatterns:
        match = re.search(pattern, newSentence, re.IGNORECASE)
        if match:
            ratings['rating'] = match.group(1)
            break

    return ratings
